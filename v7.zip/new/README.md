# LexxyOfficial

Simpel WhatsApp Bot

## FOR TERMUX USER

```
> pkg update && pkg upgrade
> pkg install git -y
> pkg install nodejs -y
> pkg install ffmpeg -y
> pkg install imagemagick -y
> git clone https://github.com/Lexxy24/BOTV7
> cd BOTV7
> npm start
```

---------

## FOR WINDOWS/VPS/RDP USER

* Download And Install Git [`Click Here`](https://git-scm.com/downloads)
* Download And Install NodeJS [`Click Here`](https://nodejs.org/en/download)
* Download And Install FFMPEG [`Click Here`](https://ffmpeg.org/download.html) (don't forget to path)
* Download And Install ImageMagick [`Click Here`](https://imagemagick.org/script/download.php) (if nulis want work,  checklist columns 1,2,3,5,6)

```
> git clone https://github.com/Lexxy24/BOTV7
> cd BOTV7
> npm install
```

---------

## Run

```bash
> node . [<session name>] (session name is optional)
```

# My Sosmed
#### Whatsapp : [`Click Here`](https://api.whatsapp.com/send/?phone=62857890047322&text&app_absent=0)
#### Grup Bot : [`Click Here`](https://chat.whatsapp.com/LeGxfgT6gjV0sdAOkYC5fG)
#### YouTube : [`Click Here`](https://youtube.com/c/LEX4YOUU)



# My Apk
#### Mt Manager : [`Click Here`](https://m.apkgit.com/app/mt-manager/bin.mt.plus)
#### Apk Termux : [`Click Here`](https://www.mediafire.com/file/f01sbphqjsd37b3/TermuxMod.apk/file)
